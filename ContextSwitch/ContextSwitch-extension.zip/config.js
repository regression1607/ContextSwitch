const CONFIG = {
  API_URL: 'https://api.context-switch.dev/api'
};
